UbioZur Welding Ltd

Version 1.1 - KSP 0.20.2.186

Created by UbioZur

--- Description ---
This mod weld some stock part together to reduce the part count and increase game performance.

The Weight, Mass, Price, Fuel quantity are done so you have the same amount as if you were building it with all the part.

Note: If you are looking for a item that is not here, feel free to ask for it.


--- Installation ---
Extract the GameData folder into the main folder where your game is installed.
	For example: C:\Program Files (x86)\Steam\steamapps\common\Kerbal Space Program



--- Usage ---
You will see the new items in the VAB and SPH, use them as every other items.

--- Known Issues ---
None found yet, if you find any please let me know.

--- Official Forum Thread ---
http://forum.kerbalspaceprogram.com/showthread.php/38577-0-20-UbioZur-Welding-Ltd-Lower-your-part-count

--- Spaceport ---
http://kerbalspaceport.com/ubioweldingltd/

--- Version History ---
1.1
ADDED Mega Jumbo
ADDED Mega Grey Jumbo
ADDED Jumbo-96
ADDED Radial Clamp-O-Tron Sr. Docking Port 2
ADDED 2x Cubic Octagonal Strut
ADDED 3x Cubic Octagonal Strut
ADDED 4x Cubic Octagonal Strut
ADDED 2x Modular Grider XL
ADDED 3x Modular Grider XL
ADDED 2x FL-R1 rCS Fuel tank

1.0
ADDED Radial Clamp-O-Tron Sr. Docking Port
ADDED Jumbo-64 FL-R1 Fuel Tank
ADDED Grey Jumbo-64
ADDED M-4x4 Structural Panel
ADDED Tri-FL-T800 Fuel Tank