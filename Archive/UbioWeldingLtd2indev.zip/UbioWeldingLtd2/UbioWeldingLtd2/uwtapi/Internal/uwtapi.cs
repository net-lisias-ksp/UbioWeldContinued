﻿using System;
using UnityEngine;

namespace UbioWeldingLtd
{
    [KSPAddon(KSPAddon.Startup.EveryScene, false)]
    public partial class uwtapi : MonoBehaviour, IWeldApi
    {
        internal static uwtapi internalInstance;
        internal uwtapi()
        {
            if (Instance == null) {
                Debug.Log(string.Format("{0} Create Interface {1}", APIConstants.logPrefix, APIConstants.logVersion));
				Instance = this;
                internalInstance = this;
				GameObject.DontDestroyOnLoad(this);
			}
		}

        /*
         * Create a new welder
         */
        public IWelder create(WeldingType type, bool cfgEditorVisible)
        {
            switch (type)
            {
                case WeldingType.AllRaw:
                    return new WelderAllRaw(cfgEditorVisible);
                    //break;
                case WeldingType.AllNoMod:
                    return new WelderAllNoMod(cfgEditorVisible);
                    //break;
                case WeldingType.Safe:
                    return new WelderSafe(cfgEditorVisible);
                    //break;
                case WeldingType.VerySafe:
                default :
                    return new WelderVerySafe(cfgEditorVisible);
                    //break;
                
            }
        }
    }
}
