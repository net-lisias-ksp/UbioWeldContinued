﻿using UnityEngine;

namespace UbioWeldingLtd
{
    static class APIConstants
    {
        //Log related constants
        public const string logVersion = "v1.0";
        public const string logWarning = "WARNING ";
        public const string logError = "ERROR ";
        public const string logPrefix = "[WeldingToolAPI] ";

        //Weld related Constants
        public const string weldPartNode = "PART";
        public const string weldPartName = "weldedpart";

        //MODULE name [STOCK]
        public const string modStockSas = "ModuleSAS";
        public const string modStockGear = "ModuleLandingGear";
        public const string modStockReacWheel = "ModuleReactionWheel";
        public const string modStockCommand = "ModuleCommand";
        public const string modStockGen = "ModuleGenerator";
        public const string modStockAltern = "ModuleAlternator";
        public const string modStockGimbal = "ModuleGimbal";
        public const string modStockSensor = "ModuleEnviroSensor";
        public const string modStockSeat = "KerbalSeat";
        public const string modStockSolarPan = "ModuleDeployableSolarPanel";
        public const string modStockJettison = "ModuleJettison";
        public const string modStockAnimHeat = "ModuleAnimateHeat";
        public const string modStockEngine = "ModuleEngines";
        public const string modStockIntake = "ModuleResourceIntake";
        public const string modStockAnimGen = "ModuleAnimateGeneric";
        public const string modStockDecouple = "ModuleDecouple";
        public const string modStockAnchdec = "ModuleAnchoredDecoupler";
        public const string modStockDocking = "ModuleDockingNode";
        public const string modStockRCS = "ModuleRCS";
        public const string modStockParachutes = "ModuleParachute";
        public const string modStockLight = "ModuleLight";
        public const string modStockRetLadder = "RetractableLadder";
        public const string modStockWheel = "ModuleWheel";
        public const string modStockFxLookAt = "FXModuleLookAtConstraint";              //Come with wheels (& Nasa Grapple .23.5)
        public const string modStockFxPos = "FXModuleConstrainPosition";                //come with wheels
        public const string modStockFxAnimThro = "FXModuleAnimateThrottle";             //ION animation throttle
        public const string modStockLaunchClamp = "LaunchClamp";
        public const string modStockScienceExp = "ModuleScienceExperiment";             //.22 Science Experiment modules
        public const string modstockTransData = "ModuleDataTransmitter";                //.22 Anteena
        public const string modStockLandingLegs = "ModuleLandingLeg";                   //.22 Lanfding legs
        public const string modStockScienceCont = "ModuleScienceContainer";             //.22 Science Container
        public const string modStockScienceLab = "ModuleScienceLab";                    //.23 Science Lab
        public const string modStockEngineFx = "ModuleEnginesFX";                       //.23 Engine with EFFECTS{}
        public const string modStockMultiEng = "MultiModeEngine";                       //.23 Multi mode engine
        public const string modStockFlagDecal = "FlagDecal";                            //.23.5 Flag Decal
        //MODULE name [NASA]
        public const string modNasaGrapple = "ModuleGrappleNode";                       //.23.5 NASA Pack
        public const string modNasaAsteroid = "ModuleAsteroid";                         //.23.5 Nasa Pack
        //MODULE name [WorldCup2014]
        public const string modWC2014Bounce = "ModuleBounce";                           //Squad Football WorldCup 2014 mod
    }
}
