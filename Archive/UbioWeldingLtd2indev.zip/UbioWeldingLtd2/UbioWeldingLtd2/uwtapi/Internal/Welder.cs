﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace UbioWeldingLtd
{
    partial class Welder : IWelder
    {
        protected WeldingType _Type;
        protected bool _EditorVisible;
        protected ConfigNode _configFile;
        protected Vector3 _com;
        protected Vector3 _coMOffset;
        protected float _fullMass;
        protected string _name;
        protected string _title;
        protected string _description;
        protected PartCategories _category;
        protected List<AttachNode> _stackNodes;
        protected AttachNode _srfAttach;
        protected AttachRules _attachRules;
        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                _name = _name.Replace(' ', '-');
                _name = _name.Replace('.', '-');
                _name = _name.Replace('\\', '-');
                _name = _name.Replace('/', '-');
                _name = _name.Replace(':', '-');
                _name = _name.Replace('*', '-');
                _name = _name.Replace('?', '-');
                _name = _name.Replace('<', '-');
                _name = _name.Replace('>', '-');
                _name = _name.Replace('|', '-');
                _name = _name.Replace('_', '-');
            }
        }
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public PartCategories Category
        {
            get { return _category; }
            set { _category = value; }
        }
        public AttachRules AttachRules
        {
            get { return _attachRules; }
            set { _attachRules = value; }
        }
        public AttachNode SrfAttach
        {
            get { return _srfAttach; }
            set { _srfAttach = value; }
        }

        WeldingType IWelder.Type()
        {
            return _Type;
        }

        /*
         * Tell if the part name is used or not
         */
        public bool isNameNotUsed()
        {
            if (String.IsNullOrEmpty(_name))
                return false;
            foreach (UrlDir.UrlConfig part in GameDatabase.Instance.GetConfigs(APIConstants.weldPartNode))
            {
                if (string.Equals(part.name, _name))
                {
                    return false;
                }
            }
            return true;
        }

        /*
         * Determine if two config files can be welded.
         */
        virtual protected bool canWeld(UrlDir.UrlConfig cfg1, UrlDir.UrlConfig cfg2)
        {
            Debug.LogError(string.Format("{0} Calling the wrong method.", APIConstants.logPrefix));
            return false;
        }

        /*
         * Merge the resources
         */
        virtual protected bool mergeResources(UrlDir.UrlConfig cfg)
        {
            ConfigNode[] currentRes = _configFile.GetNodes("RESOURCE");
            ConfigNode[] newRes = cfg.config.GetNodes("RESOURCE");
#if (DEBUG)
            Debug.Log(string.Format("{0}Currently have {1} RESOURCE, {2} to merge.", APIConstants.logPrefix, currentRes.Length, newRes.Length));
#endif
            foreach (ConfigNode res in newRes)
            {
                if (!res.HasValue("name"))
                    break;
                bool found = false;
                foreach (ConfigNode curRes in currentRes)
                {
                    if (!curRes.HasValue("name"))
                        break;
                    if (String.Equals(curRes.GetValue("name"), res.GetValue("name")))
                    {
                        //merge ressources
                        float amount = float.Parse(res.GetValue("amount")) + float.Parse(curRes.GetValue("amount"));
                        float max = float.Parse(res.GetValue("maxAmount")) + float.Parse(curRes.GetValue("maxAmount"));
                        curRes.SetValue("amount", amount.ToString());
                        curRes.SetValue("maxAmount", amount.ToString());
                        found = true;
                        Debug.Log(string.Format("{0}Resource {1} new Value {2} / {3}", APIConstants.logPrefix, curRes.GetValue("name"), amount, max));
                        break;
                    }
                }
                if (!found)
                {
                    //Add the resource
                    ConfigNode addRes = res.CreateCopy();
                    _configFile.AddNode(addRes);
                    Debug.Log(string.Format("{0}New resource {1} with Value {2} / {3}", APIConstants.logPrefix, addRes.GetValue("name"), addRes.GetValue("amount"), addRes.GetValue("maxAmount")));
                }
            }
            return true;
        }

        /*
         * Merge the Effects
         */
        virtual protected bool mergeEffects(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0} Calling the wrong method.", APIConstants.logPrefix));
            return false;
        }

        /*
         * Merge the Modules
         */
        virtual protected bool mergeModules(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0} Calling the wrong method.", APIConstants.logPrefix));
            return false;
        }

        /*
         * Merge the Internals
         */
        virtual protected bool mergeInternals(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0} Calling the wrong method.", APIConstants.logPrefix));
            return false;
        }

        /*
         * To do after the copy of the first part
         */
        virtual protected bool postFirstPartCopy()
        {
            Debug.LogError(string.Format("{0} Calling the wrong method.", APIConstants.logPrefix));
            return false;
        }

        /*
         * Clear the weld data (to do before the WeldAssembly)
         */
        public void reset()
        {
            _com = Vector3.zero;
            _coMOffset = Vector3.zero;
            _configFile = null;
            _fullMass = 0.0f;
            _name = "Internal-Name";
            _title = "Part Title";
            _description = "Description";
            _category = PartCategories.none;
            _stackNodes = new List<AttachNode>(2);
            _attachRules = new AttachRules();
            _srfAttach = new AttachNode();
        }

        /*
         * Set the position value in relation with the parents
         */
        protected void setRelativePosition(Part part, ref Vector3 position)
        {
            position += part.transform.position - part.localRoot.transform.position;
        }

        /*
         * Set relative rotation
         */
        protected void setRelativeRotation(Part part, ref Vector3 rotation)
        {
            rotation += part.transform.eulerAngles - part.localRoot.transform.eulerAngles;

            if (360.0f <= rotation.x) rotation.x -= 360.0f;
            else if (0 > rotation.x) rotation.x += 360.0f;

            if (360.0f <= rotation.y) rotation.y -= 360.0f;
            else if (0 > rotation.y) rotation.y += 360.0f;

            if (360.0f <= rotation.y) rotation.y -= 360.0f;
            else if (0 > rotation.y) rotation.y += 360.0f;
        } //private void setRelativeRotation(Part part, ref Vector3 rotation)

        /*
         * Get the mesh name
         */
        protected string getMeshurl(UrlDir.UrlConfig cfgdir)
        {
            string mesh = "model";
            //in case the mesh is not model.mu
            if (cfgdir.config.HasValue("mesh"))
            {
                mesh = cfgdir.config.GetValue("mesh");
                char[] sep = { '.' };
                string[] words = mesh.Split(sep);
                mesh = words[0];
            }
            string filename = string.Format("{0}.mu", UrlDir.PathCombine(cfgdir.parent.parent.path, mesh));
            string url = string.Format("{0}/{1}", cfgdir.parent.parent.url, mesh);

            //in case the mesh name does not exist (.22 bug / aero etc...)
            if (!File.Exists(filename))
            {
                Debug.LogWarning(string.Format("{0}{1}!Could not find the mesh {2}.", APIConstants.logWarning, APIConstants.logPrefix, filename));
                string[] files = Directory.GetFiles(cfgdir.parent.parent.path, "*.mu");
                if (files.Length != 0)
                {
                    files[0] = files[0].Remove(0, cfgdir.parent.parent.path.Length);
#if (DEBUG)
                    Debug.LogWarning(string.Format("{0}{1}New mesh name: {2}", APIConstants.logWarning, APIConstants.logPrefix, files[0]));
#endif
                    char[] sep = { '\\', '.' };
                    string[] words = files[0].Split(sep);
                    url = url.Replace(string.Format(@"{0}", mesh), words[1]);
                }
                else
                {
#if (DEBUG)
                    Debug.LogWarning(string.Format("{0}{1}No mesh found, using default", APIConstants.logWarning, APIConstants.logPrefix));
#endif
                }
            }

            return url;
        }

        /*
         * Create model node based on the part and config file
         */
        protected ConfigNode createModelNode(Part part, UrlDir.UrlConfig cfg)
        {
            ConfigNode modelNode = new ConfigNode("MODEL");
            string url = getMeshurl(cfg);
            modelNode.AddValue("model", url);
            Debug.Log(string.Format("{0} new MODEL with {1}", APIConstants.logPrefix, url));

            Vector3 position = Vector3.zero;
            modelNode.AddValue("position", ConfigNode.WriteVector(Vector3.zero));

            Vector3 rotation = part.localRoot.transform.eulerAngles;
            modelNode.AddValue("rotation", ConfigNode.WriteVector(rotation));

            return modelNode;
        }

        /*
         * Merge MODEL node (will modify modelNode)
         */
        protected void mergeModelNode(Part part, ConfigNode modelNode)
        {
            Vector3 position = (modelNode.HasValue("position")) ? ConfigNode.ParseVector3(modelNode.GetValue("position")) : Vector3.zero;
            setRelativePosition(part, ref position);
            if (modelNode.HasValue("position"))
                modelNode.SetValue("position", ConfigNode.WriteVector(position));
            else
                modelNode.AddValue("position", ConfigNode.WriteVector(position));
            _coMOffset += position;

            Vector3 rotation = (modelNode.HasValue("rotation")) ? ConfigNode.ParseVector3(modelNode.GetValue("rotation")) : Vector3.zero;
            setRelativeRotation(part, ref rotation);
            if (modelNode.HasValue("rotation"))
                modelNode.SetValue("rotation", ConfigNode.WriteVector(rotation));
            else
                modelNode.AddValue("rotation", ConfigNode.WriteVector(rotation));

            Vector3 rescaleFact = new Vector3(part.rescaleFactor - 1.0f, part.rescaleFactor - 1.0f, part.rescaleFactor - 1.0f);
            Vector3 scale = (modelNode.HasValue("scale")) ? ConfigNode.ParseVector3(modelNode.GetValue("scale")) + (rescaleFact) : new Vector3(part.rescaleFactor, part.rescaleFactor, part.rescaleFactor);
            if (modelNode.HasValue("scale"))
                modelNode.SetValue("scale", ConfigNode.WriteVector(scale));
            else
                modelNode.AddValue("scale", ConfigNode.WriteVector(scale));

            modelNode.name = "MODEL";
            _configFile.AddNode(modelNode);
#if (DEBUG)
            Debug.Log(string.Format("{0} Merge MODEL {1}", APIConstants.logPrefix, modelNode.GetValue("model")));
#endif
        }
        
        /*
         * Merge the Value for the configfile
         */
        virtual protected bool mergeValue(ConfigNode.Value value)
        {
            
            switch (value.name)
            {
                case "name": //do nothing at the moment
                    break;
                case "author": //do nothing at the moment
                    break;
                case "mesh": //will have to add the model node
                    break;
                case "scale": //will be added with the model node TODO CHECK FIX
                    break;
                case "rescaleFactor": //will be added with the model node TODO CHECK FIX
                    break;
                case "TechRequired": //TODO
                    break;
                case "entryCost": //TODO
                    break;
                case "cost": //Add cost value
                    _configFile.SetValue(value.name, Convert.ToString(Convert.ToInt32(_configFile.GetValue(value.name)) + Convert.ToInt32(value.value)));
                    break;
                case "category": //do nothing at the moment
                    break;
                case "subcategory": //do nothing at the moment
                    break;
                case "title": //do nothing at the moment
                    break;
                case "manufacturer": //do nothing at the moment
                    break;
                case "description": //do nothing at the moment
                    break;
                case "attachRules": //do nothing
                    break;
                case "mass": //add mass value
                    _configFile.SetValue(value.name, Convert.ToString(Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)));
                    break;
                case "dragModelType": //TODO
                    break;
                case "maximum_drag": // Average
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.5f));
                    break;
                case "minimum_drag": // Average
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.5f));
                    break;
                case "angularDrag": // Average
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.5f));
                    break;
                case "crashTolerance": // random equation
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.75f));
                    break;
                case "breakingForce": // random equation
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.75f));
                    break;
                case "breakingTorque": // random equation
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.75f));
                    break;
                case "maxTemp": // Average
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.5f));
                    break;
                case "vesselType": // dont do anything
                    break;
                case "fuelCrossFeed": // Or
                    _configFile.SetValue(value.name, Convert.ToString(Convert.ToBoolean(_configFile.GetValue(value.name)) || Convert.ToBoolean(value.value)));
                    break;
                case "CrewCapacity": //add mass value
                    _configFile.SetValue(value.name, Convert.ToString(Convert.ToInt32(_configFile.GetValue(value.name)) + Convert.ToInt32(value.value)));
                    break;
                case "explosionPotential": // Average
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.5f));
                    break;
                case "dragCoeff": // Average
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.5f));
                    break;
                case "deflectionLiftCoeff": // Average TODO: CHECK betwen Avg, Add etc...
                    _configFile.SetValue(value.name, Convert.ToString((Convert.ToSingle(_configFile.GetValue(value.name)) + Convert.ToSingle(value.value)) * 0.5f));
                    break;
                case "stackSymmetry": // don't do anything TODO: CHECK
                    break;
                case "mirrorRefAxis": // don't do anything TODO: CHECK
                    break;
                case "PhysicsSignificance": // remove the physics Significance if one of the file does not have it to 1!
                    if ((1 == Convert.ToInt32(_configFile.GetValue(value.name))) || (1 == Convert.ToInt32(value.value)))
                    {
                        _configFile.RemoveValue(value.name);
                    }
                    break;
                case "stagingIcon": // don't do anything TODO: Play with it
                    break;
                default:
#if (DEBUG)
                    Debug.Log(string.Format("{0} Value {1} is not part of the common welding merge.", APIConstants.logPrefix, value.name));
#endif
                    return false;
            }
            return true;
        }

        /*
         * Find the ConfigURL associated with the partname
         */
        protected UrlDir.UrlConfig FindUrlConfig(string partname)
        {
            //--- Find all the config file with the name
            List<UrlDir.UrlConfig> matchingPartConfigs = new List<UrlDir.UrlConfig>();

            foreach (UrlDir.UrlConfig config in GameDatabase.Instance.GetConfigs(APIConstants.weldPartNode))
            {
                string newconfigname = config.name.Replace('_', '.');
                if (System.String.Equals(partname, newconfigname, System.StringComparison.Ordinal))
                {
#if (DEBUG)
                    Debug.Log(string.Format("{0} config name {1}", APIConstants.logPrefix, newconfigname));
#endif
                    matchingPartConfigs.Add(config);
                }
            }

            if (0 >= matchingPartConfigs.Count)
            {
                //Missing Config File: Error
                Debug.LogError(string.Format("{0}{1}.Cannot find Config File for part: {3}", APIConstants.logError, APIConstants.logPrefix, partname));
                return null;
            }
            else if (1 > matchingPartConfigs.Count)
            {
                //We shouldn't have more than one Config file
                Debug.LogWarning(string.Format("{0}{1}.Found {2} Config Files for part: {3}", APIConstants.logWarning, APIConstants.logPrefix, matchingPartConfigs.Count, partname));
            }
            return matchingPartConfigs.First();
        } // protected UrlDir.UrlConfig FindUrlConfig(string partname)

        /*
         * Weld a new part to the Assembly
         */
        protected bool addChild(Part part, bool stopOnCantWeld)
        {
            //take first part
            string partname = (string)part.partInfo.partPrefab.name.Clone();
            WeldUtils.removeClone(ref partname);

            //Find the config URL
            UrlDir.UrlConfig MainUrl = FindUrlConfig(partname);
            if (null == MainUrl)
                return false;
            
            //Browse Children
            foreach (Part child in part.children)
            {
                string childname = (string)child.partInfo.partPrefab.name.Clone();
                WeldUtils.removeClone(ref childname);
                UrlDir.UrlConfig ChildURl = FindUrlConfig(childname);

                if (!canWeld(MainUrl, ChildURl))
                {
                    Debug.Log(string.Format("{0} Will not weld {1} with {2}", APIConstants.logPrefix, partname, childname));
                    if (stopOnCantWeld)
                        return false;
                    else
                        break;
                }
                Debug.Log(string.Format("{0} Will weld {1} with {2}", APIConstants.logPrefix, partname, childname));

                //browse all children
                if (!addChild(child, stopOnCantWeld))
                    return false;

                //Merge both config files
                foreach (ConfigNode.Value value in ChildURl.config.values)
                {
                    //make sure it's not a value we will change later
                    if (!String.Equals(value.name, "mesh") && !String.Equals(value.name, "author") && !String.Equals(value.name, "name")
                        && !String.Equals(value.name, "category") && !String.Equals(value.name, "subcategory") && !String.Equals(value.name, "title")
                        && !String.Equals(value.name, "manufacturer") && !String.Equals(value.name, "description"))
                    {
                        if (String.Equals("PhysicsSignificance", value.name))
                        {
                            if (_configFile.HasValue("PhysicsSignificance"))
                            {
                                //Merge values
                                mergeValue(value);
                            }
                        }
                        else if (value.name.StartsWith("node_stack_"))
                        {
                            string name = value.name.Remove(0, 11);
                            name += childname + child.uid;

                            string data = value.value.Replace(" ","");
                            string[] values = data.Split(',');

                            Vector3 position = new Vector3(float.Parse(values[0]),float.Parse(values[1]),float.Parse(values[2]));
                            Vector3 orientation = new Vector3(float.Parse(values[3]), float.Parse(values[4]), float.Parse(values[5]));
                            int size = (7==values.Length)?int.Parse(values[6]):1; //copy the size or default it to 1 if it doesn't exist

                            AttachNode node = new AttachNode();
                            node.id = name;
                            node.size = size;

                            Matrix4x4 rot = Matrix4x4.TRS(Vector3.zero, child.transform.rotation, Vector3.one);
                            node.position = rot.MultiplyVector(position);
                            node.orientation = rot.MultiplyVector(orientation);
                            setRelativePosition(child, ref node.position);
                            //Determine if in use with the name and set it to our stacknode
#if (DEBUG)
                            Debug.Log(string.Format("{0} New Attach node {1} {2} {3} {4}", APIConstants.logPrefix, name,node.position.ToString(), node.orientation.ToString(), node.size.ToString()));
#endif
                            _stackNodes.Add(node);
                        }
                        else if (String.Equals("node_attach", value.name))
                        {
                            //do nothing
                        }
                        else if (value.name.StartsWith("fx_"))
                        {
                            //fx stuff
                        }
                        else if (value.name.StartsWith("sound_"))
                        {
                            //sound stuff
                        }
                        else if (_configFile.HasValue(value.name))
                        {
                            //Merge values
                            mergeValue(value);
                        }
                        else
                        {
                            //Add Value
                            _configFile.AddValue(value.name, value.value);
                        }
                    }
                }

                //MODEL
                if (ChildURl.config.HasNode("MODEL"))
                {
                    foreach (ConfigNode node in ChildURl.config.GetNodes("MODEL"))
                    {
                        ConfigNode modelNode = node.CreateCopy();
                        mergeModelNode(child, modelNode);
                    }
                }
                else
                {
                    ConfigNode modelNode = createModelNode(child, ChildURl);
                    mergeModelNode(child, modelNode);
                }

                //RESOURCE
                if (ChildURl.config.HasNode("RESOURCE"))
                {
                    if (!mergeResources(ChildURl))
                        return false;
                }

                //EFFECT
                if (ChildURl.config.HasNode("EFFECTS"))
                {
                    if (!mergeEffects(ChildURl))
                        return false;
                }

                //MODULE
                if (ChildURl.config.HasNode("MODULE"))
                {
                    if (!mergeModules(ChildURl))
                        return false;
                }

                //INTERNAL
                if (ChildURl.config.HasNode("INTERNAL"))
                {
                    if (!mergeInternals(ChildURl))
                        return false;
                }

                //mass
                float oldmass = _fullMass;
                float partwetmass = child.mass + child.GetResourceMass();
                _fullMass += partwetmass;
                _com = ((_com * oldmass) + (_coMOffset * partwetmass)) / _fullMass;
#if (DEBUG)
                Debug.Log(string.Format("{0} New Center of Mass: {1}", APIConstants.logPrefix, _com.ToString()));
#endif

            } //foreach (Part child in Assembly.children)

            return true;
        }

        /*
         * Weld the Assembly
         * return if it could weld
         */
        public bool WeldAssembly(Part Assembly, bool stopOnCantWeld)
        {
            int NbAssembyNbPartStart = 1 + Assembly.children.Count;
#if (DEBUG)
            Debug.Log(string.Format("{0}{1} Assembly start with {2} parts.", APIConstants.logPrefix, _Type.ToString(), NbAssembyNbPartStart));
#endif
            //take first part
            string partname = (string)Assembly.partInfo.partPrefab.name.Clone();
            WeldUtils.removeClone(ref partname);
            
            //Find the config URL
            UrlDir.UrlConfig MainUrl = FindUrlConfig(partname);
            if (null == MainUrl)
                return false;

            reset();
#if (DEBUG)
            Debug.Log(string.Format("{0} Creating ConfigNode", APIConstants.logPrefix));
#endif
            _configFile = MainUrl.config.CreateCopy();
            _name = partname + APIConstants.weldPartName;
            _configFile.name = _name;

            if (!postFirstPartCopy())
                return false;

            foreach (AttachNode rootNode in Assembly.attachNodes)
            {

                AttachNode node = new AttachNode();
                node.id = rootNode.id + partname + Assembly.uid;
                node.position = rootNode.position;
                node.orientation = rootNode.orientation;
                node.attachedPart = rootNode.attachedPart;
#if (DEBUG)
                Debug.Log(string.Format("{0} New Attach node {1} {2} {3} {4}", APIConstants.logPrefix, node.id, node.position.ToString(), node.orientation.ToString(), node.size.ToString()));
#endif
                _stackNodes.Add(node);
            }
            _configFile.RemoveValuesStartWith("node_stack_");

            //sort the mesh/MODEL stuff
            if (!_configFile.HasNode("MODEL"))
            {
                ConfigNode modelNode = createModelNode(Assembly, MainUrl);
                mergeModelNode(Assembly, modelNode);
            }
            else
            {
                foreach (ConfigNode node in MainUrl.config.GetNodes("MODEL"))
                {
                    ConfigNode modelNode = node.CreateCopy();
                    mergeModelNode(Assembly, modelNode);
                }
            }
            if (_configFile.HasValue("model"))
                _configFile.RemoveValue("model");

            _fullMass = Assembly.mass + Assembly.GetResourceMass();

            if (!addChild(Assembly, stopOnCantWeld))
                return false;
            
            //Process the new Center Of Mass
            foreach (ConfigNode model in _configFile.GetNodes("MODEL"))
            {
                if (model.HasValue("position"))
                {
                    Vector3 position = ConfigNode.ParseVector3(model.GetValue("position"));
                    position -= _com;
                    model.SetValue("position", ConfigNode.WriteVector(position));
                }
            }
            //CoM for node_stack
            foreach (AttachNode node in _stackNodes)
            {
                node.position -= _com;
            }
            
            
            //EFFECTS / fx TODO

            //atachnode (root attachnode + com)
            _configFile.RemoveValue("node_attach");
            _srfAttach.position = Assembly.srfAttachNode.position + _com;
            _srfAttach.orientation = Assembly.srfAttachNode.originalOrientation;
            _srfAttach.size = Assembly.srfAttachNode.size;

            //attachnode rules (as root can be overwrite later)
            _configFile.RemoveValue("attachRules");
            _attachRules.allowCollision = Assembly.attachRules.allowCollision;
            _attachRules.allowDock = Assembly.attachRules.allowDock;
            _attachRules.allowRotate = Assembly.attachRules.allowRotate;
            _attachRules.allowSrfAttach = Assembly.attachRules.allowSrfAttach;
            _attachRules.allowStack = Assembly.attachRules.allowStack;
            _attachRules.srfAttach = Assembly.attachRules.srfAttach;
            _attachRules.stack = Assembly.attachRules.stack;

            return true;
        } //public void WeldAssembly(ref Part Assembly)

        /*
         * Save to a file
         */
        public void saveToFile(UrlDir configUrl, string dirpath, string fileName, bool loadcfg)
        { 
            if (String.IsNullOrEmpty(fileName) || null==configUrl)
            {
                Debug.LogError(string.Format("{0}{1}{2} path is not valid to write the cfg!", APIConstants.logError, APIConstants.logPrefix, _Type.ToString()));
                return;
            }

            _configFile.name = "PART";
            _configFile.AddValue("name", _name);
            _configFile.AddValue("title", _title);
            _configFile.AddValue("category", _category.ToString());
            _configFile.AddValue("subcategory", "weld");
            _configFile.AddValue("description", _description);
            _configFile.AddValue("manufacturer", "weld");
            _configFile.AddValue("author", "UbioWeldingTool");
            _configFile.AddValue("module", "Part");
            _configFile.AddValue("attachRules", _attachRules.String());
            _configFile.AddValue("node_attach",String.Format("{0}, {1}, {2}", ConfigNode.WriteVector(_srfAttach.position), ConfigNode.WriteVector(Vector3.Normalize(_srfAttach.orientation)), _srfAttach.size));
            //research stuff
            foreach (AttachNode node in _stackNodes)
            {
                //TODO: different stack node selection (all, nonAttached, inline)
                string name = "node_stack_" + node.id;
                string value = String.Format("{0}, {1}, {2}", ConfigNode.WriteVector(node.position), ConfigNode.WriteVector(Vector3.Normalize(node.orientation)), node.size);
                _configFile.AddValue(name, value);
            }

            //-----------------------------------------
            string filetoWrite = UrlDir.PathCombine(dirpath, String.Format("{0}.{1}", fileName, UrlDir.configExtension));
            //create the file
            if (!File.Exists(filetoWrite))
            {
                if (!Directory.Exists(dirpath))
                {
                    Directory.CreateDirectory(dirpath);
                }
                //create the file
                StreamWriter partfile = File.CreateText(filetoWrite);
                partfile.Close();
#if (DEBUG)
                Debug.Log(string.Format("{0}{1} File needed to be created", APIConstants.logPrefix, _Type.ToString()));
#endif
            }
            ConfigNode fullConfigNode = new ConfigNode(_name);
            fullConfigNode.AddNode(_configFile);
            fullConfigNode.Save(filetoWrite);

            Debug.Log(string.Format("{0}{1} Config file saved at: {2}", APIConstants.logPrefix, _Type.ToString(),filetoWrite));

            /*if (loadcfg)
            {
#if (DEBUG)
                Debug.Log(string.Format("{0}{1} Start Loading config file", APIConstants.logPrefix, _Type.ToString()));
#endif
                *//*FileInfo info = new FileInfo(filetoWrite);
                UrlDir.UrlFile fileUrl = new UrlDir.UrlFile(configUrl, info);
                UrlDir.ConfigFileType[] type = new UrlDir.ConfigFileType[] { new UrlDir.ConfigFileType(UrlDir.FileType.Config) };
                fileUrl.ConfigureFile(type);
                if(null==fileUrl)
                {
                    Debug.LogError(string.Format("{0}{1}{2} Could not create UrlDir.UrlFile for {3}", APIConstants.logError, APIConstants.logPrefix, _Type.ToString(), filetoWrite));
                    return;
                }

                UrlDir.UrlConfig cfgToLoad = fileUrl.GetConfig(_name);
                if(null==cfgToLoad || null==cfgToLoad.config)
                {
                    Debug.LogError(string.Format("{0}{1}{2} No config of the name {3} in the file {4}", APIConstants.logError, APIConstants.logPrefix, _Type.ToString(), _name, filetoWrite));
                    return;
                }*/

                /*Type DB = typeof(GameDatabase);
                Debug.Log(DB);
                System.Reflection.MethodInfo MFDB = DB.GetMethod("CreateDatabase", BindingFlags.NonPublic | BindingFlags.Instance);
                System.Reflection.MethodInfo Reset = DB.GetMethod("Reset", BindingFlags.NonPublic | BindingFlags.Instance);
                Debug.Log(MFDB);
                GameDatabase instdb = GameDatabase.Instance;
                Debug.Log(instdb);

                Reset.Invoke(instdb, null);
                MFDB.Invoke(instdb, null);

                
                Type PL = typeof(PartLoader);
                Debug.Log(PL);
                System.Reflection.MethodInfo MF = PL.GetMethod("ParsePart", BindingFlags.NonPublic | BindingFlags.Instance);
                Debug.Log(MF);
                PartLoader inst = PartLoader.Instance;
                Debug.Log(inst);

                AvailablePart p = MF.Invoke(inst, new object[] { cfgToLoad, cfgToLoad.config }) as AvailablePart;
                Debug.Log(p.title);
                Debug.Log(cfgToLoad.url);

                System.Reflection.MethodInfo MFCompile = PL.GetMethod("CompileAll", BindingFlags.NonPublic | BindingFlags.Instance);
                Debug.Log(MFCompile);
                MFCompile.Invoke(inst, null);*/
                
                
                //typeof(PartLoader).GetMethod("ParsePart").Invoke(PartLoader.Instance, new object[] { cfgToLoad, cfgToLoad.config });

                /*Debug.Log(string.Format("{0}{1} Config file reloaded", APIConstants.logPrefix, _Type.ToString()));
            }*/
            
        } //void saveToFile(string parth, bool loadcfg)

        /*
         * Average MODULE field value (int)
         */
        protected void ModuleFieldAverage(ConfigNode incfg, string field, ConfigNode outcfg)
        {
            if (incfg.HasValue(field))
            {
                if (outcfg.HasValue(field))
                {
                    int value = (int)((float.Parse(incfg.GetValue(field)) + float.Parse(outcfg.GetValue(field))) * 0.5f);
                    outcfg.SetValue(field, value.ToString());
                }
                else
                {
                    outcfg.AddValue(field, incfg.GetValue(field));
                }
            }
        }

        /*
         * Average MODULE field value (float)
         */
        protected void ModuleFieldAveragef(ConfigNode incfg, string field, ConfigNode outcfg)
        {
            if (incfg.HasValue(field))
            {
                if (outcfg.HasValue(field))
                {
                    float value = (float.Parse(incfg.GetValue(field)) + float.Parse(outcfg.GetValue(field))) * 0.5f;
                    outcfg.SetValue(field, value.ToString());
                }
                else
                {
                    outcfg.AddValue(field, incfg.GetValue(field));
                }
            }
        }

        /*
         * Add MODULE field value (int)
         */
        protected void ModuleFieldAdd(ConfigNode incfg, string field, ConfigNode outcfg)
        {
            if (incfg.HasValue(field))
            {
                if (outcfg.HasValue(field))
                {
                    int value = int.Parse(incfg.GetValue(field)) + int.Parse(outcfg.GetValue(field));
                    outcfg.SetValue(field, value.ToString());
                }
                else
                {
                    outcfg.AddValue(field, incfg.GetValue(field));
                }
            }
        }

        /*
         * Add MODULE field value (float)
         */
        protected void ModuleFieldAddf(ConfigNode incfg, string field, ConfigNode outcfg)
        {
            if (incfg.HasValue(field))
            {
                if (outcfg.HasValue(field))
                {
                    float value = float.Parse(incfg.GetValue(field)) + float.Parse(outcfg.GetValue(field));
                    outcfg.SetValue(field, value.ToString());
                }
                else
                {
                    outcfg.AddValue(field, incfg.GetValue(field));
                }
            }
        }

        /*
         * And gate MODULE field value
         */
        protected void ModuleFieldAnd(ConfigNode incfg, string field, ConfigNode outcfg)
        {
            if (incfg.HasValue(field))
            {
                if (outcfg.HasValue(field))
                {
                    bool value = bool.Parse(incfg.GetValue(field)) && bool.Parse(outcfg.GetValue(field));
                    outcfg.SetValue(field, value.ToString());
                }
                else
                {
                    outcfg.AddValue(field, incfg.GetValue(field));
                }
            }
        }

        /*
         * Or gate MODULE field value
         */
        protected void ModuleFieldOr(ConfigNode incfg, string field, ConfigNode outcfg)
        {
            if (incfg.HasValue(field))
            {
                if (outcfg.HasValue(field))
                {
                    bool value = bool.Parse(incfg.GetValue(field)) || bool.Parse(outcfg.GetValue(field));
                    outcfg.SetValue(field, value.ToString());
                }
                else
                {
                    outcfg.AddValue(field, incfg.GetValue(field));
                }
            }
        }

        /*
         * Add String MODULE field value if non existant
         */
        protected void ModuleFieldAddString(ConfigNode incfg, string field, ConfigNode outcfg)
        {
            if (incfg.HasValue(field) && !outcfg.HasValue(field))
            {
                outcfg.AddValue(field, incfg.GetValue(field));
            }
        }
    }
}
