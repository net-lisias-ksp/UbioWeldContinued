﻿using UnityEngine;

namespace UbioWeldingLtd
{
    class WelderAllNoMod : Welder
    {
        public WelderAllNoMod(bool cfgEditorVisible)
            : base()
        {
            _Type = WeldingType.AllNoMod;
            _EditorVisible = cfgEditorVisible;
            reset();
            Debug.Log(string.Format("{0} Creating a new {1} welder.", APIConstants.logPrefix, _Type.ToString()));            
        }

        /*
        * Determine if two config files can be welded.
        */
        protected override bool canWeld(UrlDir.UrlConfig cfg1, UrlDir.UrlConfig cfg2)
        {
            return true;
        }

        /*
         * Merge the Value for the configfile
         */
        protected override bool mergeValue(ConfigNode.Value value)
        {
            //Specific for the welder
            switch (value.name)
            {
                case "module": //should be the same as the main part
                    return true;

                default:
                    //Base default value
                    return base.mergeValue(value);
            }
        }

        /*
         * Merge the resources
         */
        protected override bool mergeResources(UrlDir.UrlConfig cfg)
        {
            Debug.Log(string.Format("{0} {1} Wont Merge RESSOURCES.", APIConstants.logPrefix, _Type.ToString()));
            return true;
        }

        /*
         * Merge the Effects
         */
        protected override bool mergeEffects(UrlDir.UrlConfig cfg)
        {
            Debug.Log(string.Format("{0} {1} Wont Merge EFFECTS.", APIConstants.logPrefix, _Type.ToString()));
            return true;
        }

        /*
         * Merge the Modules
         */
        protected override bool mergeModules(UrlDir.UrlConfig cfg)
        {
            Debug.Log(string.Format("{0} {1} Wont Merge MODULES.", APIConstants.logPrefix, _Type.ToString()));
            return true;
        }

        /*
         * Merge the Internals
         */
        protected override bool mergeInternals(UrlDir.UrlConfig cfg)
        {
            Debug.Log(string.Format("{0} {1} Wont Merge INTERNAL.", APIConstants.logPrefix, _Type.ToString()));
            return true;
        }

        /*
         * To do after the copy of the first part
         */
        protected override bool postFirstPartCopy()
        {
            //remove any ressources, modules effects and other from the config file
            if (_configFile.HasNode("RESOURCE"))
            {
                _configFile.RemoveNodes("RESOURCE");
            }
            if (_configFile.HasNode("MODULE"))
            {
                _configFile.RemoveNodes("MODULE");
            }
            if (_configFile.HasNode("INTERNAL"))
            {
                _configFile.RemoveNodes("INTERNAL");
            }
            if (_configFile.HasNode("EFFECTS"))
            {
                _configFile.RemoveNodes("EFFECTS");
            }
            //TODO remove fx_
            //TODO remove sound_

            return true;
        }
    }
}
