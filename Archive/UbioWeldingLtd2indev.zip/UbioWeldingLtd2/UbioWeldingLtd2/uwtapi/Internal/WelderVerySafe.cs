﻿using UnityEngine;

namespace UbioWeldingLtd
{
    partial class WelderVerySafe : Welder
    {
        
        public WelderVerySafe(bool cfgEditorVisible) : base()
        {
            _Type = WeldingType.VerySafe;
            _EditorVisible = cfgEditorVisible;
            reset();
            Debug.Log(string.Format("{0} Creating a new {1} welder.", APIConstants.logPrefix, _Type.ToString()));            
        }

        /*
        * Determine if two config files can be welded.
        */
        protected override bool canWeld(UrlDir.UrlConfig cfg1, UrlDir.UrlConfig cfg2)
        {
            //If it's a different type of module don't weld
            if (!string.Equals(cfg1.config.GetValue("module"), cfg2.config.GetValue("module")))
                return false;
            //if any of the config files have modules, don't weld.
            if (cfg1.config.HasNode("MODULE") || cfg2.config.HasNode("MODULE"))
                return false;
            //if any of the config files have internal, don't weld.
            if (cfg1.config.HasNode("INTERNAL") || cfg2.config.HasNode("INTERNAL"))
                return false;
            //if any of the config files have Effects node, don't weld.
            if (cfg1.config.HasNode("EFFECTS") || cfg2.config.HasNode("EFFECTS"))
                return false;
            //both must have ressources or no ressources
            if (cfg1.config.HasNode("RESOURCE") ^ cfg2.config.HasNode("RESOURCE"))
                return false;
            return true;
        }

        /*
         * Merge the Value for the configfile
         */
        protected override bool mergeValue(ConfigNode.Value value)
        {
            //Specific for the welder
            switch (value.name)
            {
                case "module": //should be the same as the main part
                    return true;
                    
                default:
                    //Base default value
                    return base.mergeValue(value);
            }
        }

        /*
         * Merge the resources
         */
        protected override bool mergeResources(UrlDir.UrlConfig cfg)
        {
            //use the default one
            return base.mergeResources(cfg);
        }

        /*
         * Merge the Effects
         */
        protected override bool mergeEffects(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0} {1} Cannot weld EFFECTS.", APIConstants.logPrefix, _Type.ToString()));
            return false;
        }

        /*
         * Merge the Modules
         */
        protected override bool mergeModules(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0} {1} Cannot weld MODULE.", APIConstants.logPrefix, _Type.ToString()));
            return false;
        }

        /*
         * Merge the Internals
         */
        protected override bool mergeInternals(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0} {1} Cannot weld INTERNAL.", APIConstants.logPrefix, _Type.ToString()));
            return false;
        }

        /*
         * To do after the copy of the first part
         */
        protected override bool postFirstPartCopy()
        {
            //do nothing
            return true;
        }
    }
}
