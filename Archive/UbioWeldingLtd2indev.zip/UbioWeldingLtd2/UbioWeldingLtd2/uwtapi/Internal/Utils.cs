﻿using System;
using System.Text.RegularExpressions;

namespace UbioWeldingLtd
{
    static public class WeldUtils
    {
        /*
         * Remove all the (Clone) at the end of the names
         */
        static public void removeClone(ref string name)
        {
            const string clone = "(Clone)";
            while (new Regex(clone).IsMatch(name))
            {
                name = name.Substring(0, name.Length - clone.Length);
            }
        }
    }
}
