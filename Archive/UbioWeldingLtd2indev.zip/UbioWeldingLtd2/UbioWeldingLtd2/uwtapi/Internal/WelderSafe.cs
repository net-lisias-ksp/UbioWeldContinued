﻿using UnityEngine;
using System.Linq;

namespace UbioWeldingLtd
{
    class WelderSafe : Welder
    {
        public WelderSafe(bool cfgEditorVisible)
            : base()
        {
            _Type = WeldingType.Safe;
            _EditorVisible = cfgEditorVisible;
            reset();
            Debug.Log(string.Format("{0} Creating a new {1} welder.", APIConstants.logPrefix, _Type.ToString()));            
        }

        /*
        * Determine if two config files can be welded.
        */
        protected override bool canWeld(UrlDir.UrlConfig cfg1, UrlDir.UrlConfig cfg2)
        {
            //If it's a different type of module don't weld
            if (!string.Equals(cfg1.config.GetValue("module"), cfg2.config.GetValue("module")))
                return false;
            //if any of the config files have internal, don't weld.
            if (cfg1.config.HasNode("INTERNAL") || cfg2.config.HasNode("INTERNAL"))
                return false;
            //if any of the config files have Effects node, don't weld.
            if (cfg1.config.HasNode("EFFECTS") || cfg2.config.HasNode("EFFECTS"))
                return false;
            return true;
        }

        /*
         * Merge the Value for the configfile
         */
        protected override bool mergeValue(ConfigNode.Value value)
        {
            //Specific for the welder
            switch (value.name)
            {
                case "module": //should be the same as the main part
                    return true;
                    
                default:
                    //Base default value
                    return base.mergeValue(value);
            }
        }

        /*
         * Merge the resources
         */
        protected override bool mergeResources(UrlDir.UrlConfig cfg)
        {
            //use the default one
            return base.mergeResources(cfg);
        }

        /*
         * Merge the Effects
         */
        protected override bool mergeEffects(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0} {1} Cannot weld EFFECTS.", APIConstants.logPrefix, _Type.ToString()));
            return false;
        }

        /*
         * Merge the Modules
         */
        protected override bool mergeModules(UrlDir.UrlConfig cfg)
        {
            foreach (ConfigNode node in cfg.config.GetNodes("MODULE"))
            {
                //TODO: Use Linq
                bool exist = false;
                if( !node.HasValue("name") )
                {
                    Debug.LogError(string.Format("{0} {1} MODULE does not have a name", APIConstants.logPrefix, _Type.ToString()));
                    return false;
                }
                string name = node.GetValue("name");
                foreach (ConfigNode mergeNode in _configFile.GetNodes("MODULE"))
                {
                    if (!mergeNode.HasValue("name"))
                    {
                        Debug.LogError(string.Format("{0} {1} merged MODULE does not have a name", APIConstants.logPrefix, _Type.ToString()));
                        return false;
                    }
                    if (string.Equals(name, mergeNode.GetValue("name")))
                    {
                        exist = true;
                        switch (name)
                        {
                                //Ignore those MODULE, not neccessary to have more than one
                            case APIConstants.modStockSas : 
                            case APIConstants.modStockGear:
                            case APIConstants.modNasaAsteroid:
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                                //Add those MODULE if different variable value
                            case APIConstants.modStockRCS:
                                exist = string.Equals(mergeNode.GetValue("RCSthruster"), node.GetValue("RCSthruster")) && string.Equals(mergeNode.GetValue("resourceName"), node.GetValue("resourceName"));
                                if (exist)
                                {
#if (DEBUG)
                                    Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2} with the same RCSthruster and resourceName", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                break;
                            case APIConstants.modStockAnimHeat:
                                exist = string.Equals(mergeNode.GetValue("ThermalAnim"), node.GetValue("ThermalAnim"));
                                if (exist)
                                {
#if (DEBUG)
                                    //TODO: Cancel weld?
                                    Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2} with the same ThermalAnim (Break Animation)", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                break;
                            case APIConstants.modStockAnimGen:
                                exist = string.Equals(mergeNode.GetValue("animationName"), node.GetValue("animationName"));
                                if (exist)
                                {
#if (DEBUG)
                                    //TODO: Cancel weld?
                                    Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2} with the same animationName (Break Animation)", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                break;
                            case APIConstants.modStockScienceExp:
                                exist = string.Equals(mergeNode.GetValue("experimentID"), node.GetValue("experimentID"));
                                if (exist)
                                {
#if (DEBUG)
                                    //TODO: Cancel weld?
                                    Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2} with the same experiment ID", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                break;
                            case APIConstants.modStockLandingLegs:
                                exist = string.Equals(mergeNode.GetValue("animationName"), node.GetValue("animationName"));
                                if (exist)
                                {
#if (DEBUG)
                                    //TODO: Cancel weld?
                                    Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2} with the same animationName", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                break;
                            case APIConstants.modNasaGrapple:
                                exist = string.Equals(mergeNode.GetValue("nodeTransformName"), node.GetValue("nodeTransformName"));
                                if (exist)
                                {
#if (DEBUG)
                                    //TODO: Cancel weld?
                                    Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2} with the same nodeTransformName", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                break;
                            case APIConstants.modStockFlagDecal:
                                exist = string.Equals(mergeNode.GetValue("textureQuadName"), node.GetValue("textureQuadName"));
                                if (exist)
                                {
#if (DEBUG)
                                    Debug.Log(string.Format("{0}{1} Ignore another instance of the module {2} with the same textureQuadName", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                break;
                                //Merge those MODULE
                            case APIConstants.modStockReacWheel:
                                ModuleFieldAddf(node, "PitchTorque", mergeNode);
                                ModuleFieldAddf(node, "YawTorque", mergeNode);
                                ModuleFieldAddf(node, "RollTorque", mergeNode);

                                //TODO: Linq to managed several ressources
                                if (node.HasNode("RESOURCE"))
                                {
                                    if (mergeNode.HasNode("RESOURCE") && string.Equals(node.GetNode("RESOURCE").GetValue("name"), mergeNode.GetNode("RESOURCE").GetValue("name")))
                                    {
                                        ConfigNode resNode = node.GetNode("RESOURCE");
                                        ConfigNode mergedResNode = mergeNode.GetNode("RESOURCE");
                                        ModuleFieldAddf(resNode, "rate", mergedResNode);
                                    }
                                    else
                                    {
                                        mergeNode.AddNode(node.GetNode("RESOURCE"));
                                    }
                                }
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            case APIConstants.modStockCommand:
                                ModuleFieldAdd(node, "minimumCrew", mergeNode);

                                //TODO: Linq to managed several ressources
                                if (node.HasNode("RESOURCE"))
                                {
                                    if (mergeNode.HasNode("RESOURCE") && string.Equals(node.GetNode("RESOURCE").GetValue("name"), mergeNode.GetNode("RESOURCE").GetValue("name")))
                                    {
                                        ConfigNode resNode = node.GetNode("RESOURCE");
                                        ConfigNode mergedResNode = mergeNode.GetNode("RESOURCE");
                                        ModuleFieldAddf(resNode, "rate", mergedResNode);
                                    }
                                    else
                                    {
                                        mergeNode.AddNode(node.GetNode("RESOURCE"));
                                    }
                                }
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            case APIConstants.modStockGen:
                                ModuleFieldAnd(node, "isAlwaysActive", mergeNode);

                                //TODO: Linq to managed several (input) ressources
                                if (node.HasNode("RESOURCE"))
                                {
                                    if (mergeNode.HasNode("RESOURCE") && string.Equals(node.GetNode("RESOURCE").GetValue("name"), mergeNode.GetNode("RESOURCE").GetValue("name")))
                                    {
                                        ConfigNode resNode = node.GetNode("RESOURCE");
                                        ConfigNode mergedResNode = mergeNode.GetNode("RESOURCE");
                                        ModuleFieldAddf(resNode, "rate", mergedResNode);
                                    }
                                    else
                                    {
                                        mergeNode.AddNode(node.GetNode("RESOURCE"));
                                    }
                                }

                                //TODO: Linq to managed several (output) ressources
                                if (node.HasNode("OUTPUT_RESOURCE"))
                                {
                                    if (mergeNode.HasNode("OUTPUT_RESOURCE") && string.Equals(node.GetNode("OUTPUT_RESOURCE").GetValue("name"), mergeNode.GetNode("OUTPUT_RESOURCE").GetValue("name")))
                                    {
                                        ConfigNode resNode = node.GetNode("OUTPUT_RESOURCE");
                                        ConfigNode mergedResNode = mergeNode.GetNode("OUTPUT_RESOURCE");
                                        ModuleFieldAddf(resNode, "rate", mergedResNode);
                                    }
                                    else
                                    {
                                        mergeNode.AddNode(node.GetNode("OUTPUT_RESOURCE"));
                                    }
                                }
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            case APIConstants.modStockAltern:
                                //TODO: Linq to managed several (output) ressources
                                if (node.HasNode("RESOURCE"))
                                {
                                    if (mergeNode.HasNode("RESOURCE") && string.Equals(node.GetNode("RESOURCE").GetValue("name"), mergeNode.GetNode("RESOURCE").GetValue("name")))
                                    {
                                        ConfigNode resNode = node.GetNode("RESOURCE");
                                        ConfigNode mergedResNode = mergeNode.GetNode("RESOURCE");
                                        ModuleFieldAddf(resNode, "rate", mergedResNode);
                                    }
                                    else
                                    {
                                        mergeNode.AddNode(node.GetNode("RESOURCE"));
                                    }
                                }
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            case APIConstants.modStockGimbal:
                                ModuleFieldAverage(node, "gimbalRange", mergeNode);
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            case APIConstants.modstockTransData:
                                if( string.Equals(mergeNode.GetValue("requiredResource"), node.GetValue("requiredResource")) )
                                {
                                    //merge value
                                    ModuleFieldAveragef(node, "packetInterval", mergeNode);
                                    ModuleFieldAddf(node, "packetSize", mergeNode);
                                    ModuleFieldAddf(node, "packetResourceCost", mergeNode);
                                    //TODO: DeployFxModule ???
                                    if( !mergeNode.HasValue("ProgressFxModules") && node.HasValue("ProgressFxModules") )
                                    {
                                        mergeNode.AddValue("ProgressFxModules",node.GetValue("ProgressFxModules"));
                                    }
#if (DEBUG)
                                    Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                }
                                else
                                    exist = false;
                                break;
                            case APIConstants.modStockScienceCont:
                                ModuleFieldOr(node, "evaOnlyStorage", mergeNode);
                                ModuleFieldAverage(node, "storageRange", mergeNode);
                                ModuleFieldAddString(node, "reviewActionName", mergeNode);
                                ModuleFieldAddString(node, "storeActionName", mergeNode);
                                ModuleFieldAddString(node, "collectActionName", mergeNode);
                                ModuleFieldAnd(node, "allowRepeatedSubjects", mergeNode);
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            case APIConstants.modStockScienceLab:
                                //TODO: containerModuleIndex ???
                                if (!mergeNode.HasValue("ProgressFxModules") && node.HasValue("ProgressFxModules"))
                                {
                                    mergeNode.AddValue("ProgressFxModules", node.GetValue("ProgressFxModules"));
                                }
                                ModuleFieldAveragef(node, "dataTransmissionBoost", mergeNode);
                                ModuleFieldAdd(node, "crewsRequired", mergeNode);
                                ModuleFieldOr(node, "canResetConnectedModules", mergeNode);
                                ModuleFieldOr(node, "canResetNearbyModules", mergeNode);
                                ModuleFieldAverage(node, "interactionRange", mergeNode);

                                if (node.HasNode("RESOURCE_PROCESS"))
                                {
                                    if (mergeNode.HasNode("RESOURCE_PROCESS") && string.Equals(node.GetNode("RESOURCE_PROCESS").GetValue("name"), mergeNode.GetNode("RESOURCE_PROCESS").GetValue("name")))
                                    {
                                        ConfigNode resNode = node.GetNode("RESOURCE_PROCESS");
                                        ConfigNode mergedResNode = mergeNode.GetNode("RESOURCE_PROCESS");
                                        ModuleFieldAddf(resNode, "amount", mergedResNode);
                                    }
                                    else
                                    {
                                        mergeNode.AddNode(node.GetNode("RESOURCE_PROCESS"));
                                    }
                                }
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            case APIConstants.modWC2014Bounce:
                                ModuleFieldAveragef(node, "bounciness", mergeNode);
                                ModuleFieldAveragef(node, "dynamicFriction", mergeNode);
#if (DEBUG)
                                Debug.Log(string.Format("{0}{1} Merge Values of MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                                break;
                            //Generate Error on multiple TODO: Test after each update if it's now allowed
                            case APIConstants.modStockSeat:
                            case APIConstants.modStockSolarPan:
                            case APIConstants.modStockJettison:
                            case APIConstants.modStockFxAnimThro:
                            case APIConstants.modStockIntake:
                            case APIConstants.modStockDecouple:
                            case APIConstants.modStockAnchdec:
                            case APIConstants.modStockDocking:
                            case APIConstants.modStockParachutes:
                            case APIConstants.modStockLight:
                            case APIConstants.modStockRetLadder:
                            case APIConstants.modStockWheel:
                            case APIConstants.modStockFxLookAt:
                            case APIConstants.modStockFxPos:
                            case APIConstants.modStockLaunchClamp:
                            case APIConstants.modStockEngineFx:
                            case APIConstants.modStockMultiEng:
                                Debug.LogError(string.Format("{0}{1} {2} Cannot weld multiple MODULE {3}.", APIConstants.logError, APIConstants.logPrefix, _Type.ToString(), name));
                                return false;
                                //New update or unknown mod
                            default:
                                Debug.LogError(string.Format("{0}{1} {2} MODULE {3} is unknown to us (new ksp update or unmannaged mod) and cannot be safely welded with this type of welder.", APIConstants.logError, APIConstants.logPrefix, _Type.ToString(), name));
                                return false;
                        }
                    }
                    
                }
                if (!exist)
                {
                    //Add the module
                    ConfigNode addNode = node.CreateCopy();
                    switch (addNode.GetValue("name"))
                    {
                        case APIConstants.modStockDecouple:
                        case APIConstants.modStockAnchdec:
                        case APIConstants.modStockDocking:
                        case APIConstants.modStockJettison:
                        case APIConstants.modStockEngine:
                        case APIConstants.modStockEngineFx:
                            Debug.LogError(string.Format("{0}{1} {2} Cannot weld MODULE {3}.", APIConstants.logError, APIConstants.logPrefix, _Type.ToString(), name));
                                return false;
                    }
                    _configFile.AddNode(addNode);
#if (DEBUG)
                    Debug.Log(string.Format("{0}{1} Add MODULE {2}", APIConstants.logPrefix, _Type.ToString(), name));
#endif
                    break;
                }
            }
            return true;
        }

        /*
         * Merge the Internals
         */
        protected override bool mergeInternals(UrlDir.UrlConfig cfg)
        {
            Debug.LogError(string.Format("{0}{1} {2} Cannot weld INTERNAL.",APIConstants.logError, APIConstants.logPrefix, _Type.ToString()));
            return false;
        }

        /*
         * To do after the copy of the first part
         */
        protected override bool postFirstPartCopy()
        {
            foreach (ConfigNode module in _configFile.GetNodes("MODULE"))
            {
                switch (module.GetValue("name"))
                {
                    case APIConstants.modStockDecouple:
                    case APIConstants.modStockAnchdec:
                    case APIConstants.modStockDocking:
                    case APIConstants.modStockJettison:
                    case APIConstants.modStockEngine:
                    case APIConstants.modStockEngineFx:
                        Debug.LogError(string.Format("{0}{1} {2} Cannot weld MODULE {3}.", APIConstants.logError, APIConstants.logPrefix, _Type.ToString(), module.GetValue("name")));
                        return false;
                }
            }
            return true;
        }
    }
}
