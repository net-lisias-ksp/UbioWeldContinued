﻿using UnityEngine;

namespace UbioWeldingLtd
{
    class WelderAllRaw : Welder
    {
        public WelderAllRaw(bool cfgEditorVisible)
            : base()
        {
            _Type = WeldingType.AllRaw;
            _EditorVisible = cfgEditorVisible;
            reset();
            Debug.Log(string.Format("{0} Creating a new {1} welder.", APIConstants.logPrefix, _Type.ToString()));            
        }

        /*
        * Determine if two config files can be welded. TODO
        */
        protected override bool canWeld(UrlDir.UrlConfig cfg1, UrlDir.UrlConfig cfg2)
        {
            return true;
        }

        /*
         * Merge the Value for the configfile TODO
         */
        protected override bool mergeValue(ConfigNode.Value value)
        {
            //Specific for the welder
            switch (value.name)
            {
                case "module": //should be the same as the main part
                    return true;

                default:
                    //Base default value
                    return base.mergeValue(value);
            }
        }

        /*
         * Merge the resources
         */
        protected override bool mergeResources(UrlDir.UrlConfig cfg)
        {
            ConfigNode[] newRes = cfg.config.GetNodes("RESOURCE");
#if (DEBUG)
            Debug.Log(string.Format("{0} {1} {2} RESSOURCES to add.", APIConstants.logPrefix, _Type.ToString(), newRes.Length));
#endif
            foreach (ConfigNode res in newRes)
            {
                if (!res.HasValue("name"))
                    break;
                
                //Add the resource
                ConfigNode addRes = res.CreateCopy();
                _configFile.AddNode(addRes);
                Debug.Log(string.Format("{0} {1} New resource {1} with Value {2} / {3}", APIConstants.logPrefix, _Type.ToString(), addRes.GetValue("name"), addRes.GetValue("amount"), addRes.GetValue("maxAmount")));
            }
            return true;
        }

        /*
         * Merge the Effects
         */
        protected override bool mergeEffects(UrlDir.UrlConfig cfg)
        {
            ConfigNode[] newEffects = cfg.config.GetNodes("EFFECTS");
#if (DEBUG)
            Debug.Log(string.Format("{0} {1} {2} EFFECTS to add.", APIConstants.logPrefix, _Type.ToString(), newEffects.Length));
#endif
            foreach (ConfigNode eff in newEffects)
            {
                //Add the resource
                ConfigNode addEffects = eff.CreateCopy();
                _configFile.AddNode(addEffects);
            }
            
            return true;
        }

        /*
         * Merge the Modules
         */
        protected override bool mergeModules(UrlDir.UrlConfig cfg)
        {
            ConfigNode[] newMod = cfg.config.GetNodes("MODULE");
#if (DEBUG)
            Debug.Log(string.Format("{0} {1} {2} MODULES to add.", APIConstants.logPrefix, _Type.ToString(), newMod.Length));
#endif
            foreach (ConfigNode mod in newMod)
            {
                //Add the resource
                ConfigNode addMod = mod.CreateCopy();
                _configFile.AddNode(addMod);
            }

            return true;
        }

        /*
         * Merge the Internals
         */
        protected override bool mergeInternals(UrlDir.UrlConfig cfg)
        {
            ConfigNode[] newInt = cfg.config.GetNodes("INTERNAL");
#if (DEBUG)
            Debug.Log(string.Format("{0} {1} {2} INTERNAL to add.", APIConstants.logPrefix, _Type.ToString(), newInt.Length));
#endif
            foreach (ConfigNode intern in newInt)
            {
                //Add the resource
                ConfigNode addint = intern.CreateCopy();
                _configFile.AddNode(addint);
            }
            return true;
        }

        /*
         * To do after the copy of the first part
         */
        protected override bool postFirstPartCopy()
        {
            //Nothing here
            return true;
        }
    }
}
