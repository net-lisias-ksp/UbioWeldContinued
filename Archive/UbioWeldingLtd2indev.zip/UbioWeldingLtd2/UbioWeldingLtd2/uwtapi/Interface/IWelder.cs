﻿

namespace UbioWeldingLtd
{
    public interface IWelder
    {
        /* Return the type of welder */
        WeldingType Type();

        /*
         * Modify the assembly to a welded part
         */
        bool WeldAssembly(Part Assembly, bool stopOnCantWeld = true);

        /*
         * Clear the weld data (to do before the WeldAssembly)
         */
        void reset();

        /*
         * Tell if the part name is used or not
         */
        bool isNameNotUsed();

        /*
         * Save to a file
         * loadcfg not working at the moment
         */
        void saveToFile(UrlDir configUrl, string dirpath, string fileName, bool loadcfg);


        //Accessor
        string Name { get; set; }
        string Title { get; set; }
        string Description { get; set; }
        PartCategories Category { get; set; }
        AttachRules AttachRules { get; set; }
        AttachNode SrfAttach { get; set; }
    }

}
