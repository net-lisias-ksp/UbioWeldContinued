﻿using System;
using UnityEngine;

namespace UbioWeldingLtd
{
    public enum WeldingType
    {
        VerySafe = 0,               // Only weld parts of similar type without modules (structural / fuel tanks etc...)
        Safe,                       // Only weld parts that are known to works together with modules that works
        AllNoMod,                   // Weld all part to generate a part without any modules/effects (ressources?).
        AllRaw                      // Weld all part and module without merging
    }
}

namespace UbioWeldingLtd
{
    public interface IWeldApi
    {
        /*
         * Create a new welder of the type require
         * EditorVisible = Determine if the part are visible in the editor.
         */
        IWelder create(WeldingType type = WeldingType.VerySafe, bool cfgEditorVisible = false);
    }

    public partial class uwtapi : MonoBehaviour, IWeldApi
    {
        /// <summary>
        /// The global tool bar manager instance.
        /// </summary>
        public static IWeldApi Instance
        {
            get;
            private set;
        }
    }
}
