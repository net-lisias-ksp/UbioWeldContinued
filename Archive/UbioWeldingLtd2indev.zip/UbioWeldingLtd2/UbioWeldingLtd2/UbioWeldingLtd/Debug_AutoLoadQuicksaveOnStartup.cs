﻿#if (DEBUG)
using UnityEngine;

namespace UbioWeldingLtd
{
    /**
     * Autoload the save game if we are in debug
     **/
    [KSPAddon(KSPAddon.Startup.MainMenu, false)]
    public class Debug_AutoLoadQuicksaveOnStartup : UnityEngine.MonoBehaviour
    {
        public static bool first = true;
        public void Start()
        {
            if (first)
            {
                first = false;
                HighLogic.SaveFolder = "UbioCareer"; // "UbioCareer"  "UbioZurWelding";
                var game = GamePersistence.LoadGame("persistent", HighLogic.SaveFolder, true, false);
                if (game != null && game.flightState != null && game.compatible)
                {
                    HighLogic.LoadScene(GameScenes.SPACECENTER);// FlightDriver.StartAndFocusVessel(game, game.flightState.activeVesselIdx);
                    CheatOptions.AllowPartClipping = true;
                    CheatOptions.InfiniteFuel = true;
                    CheatOptions.InfiniteRCS = true;
                }
            }
        }
    }
}
#endif