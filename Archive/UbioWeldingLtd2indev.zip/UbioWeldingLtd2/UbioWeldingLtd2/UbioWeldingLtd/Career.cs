﻿using UnityEngine;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Collections;

namespace UbioWeldingLtd
{
    [KSPAddon(KSPAddon.Startup.SpaceCentre, true)]
    class Career : MonoBehaviour
    {
        bool _career;
        bool _techNodeCreated;
        bool _onRnDSpawn;
        static GameObject nodePrefab;
        static RDNode model;
        
        
        public void Start()
        {
            //Only do anything in Career
            _career = (Game.Modes.CAREER == HighLogic.CurrentGame.Mode);
            if (!_career)
                return;

            _techNodeCreated = false;
            _onRnDSpawn = false;
            GameEvents.onGUIRnDComplexSpawn.Add(new EventVoid.OnEvent(onGUIRnDComplexSpawn));
            //GameEvents.onGameSceneLoadRequested.Add(new EventData<GameScenes>.OnEvent(OnGameSceneLoadRequested));
            
        }

        void onGUIRnDComplexSpawn()
        {
#if (DEBUG)
            Debug.Log(string.Format("{0} Spawn RnD Complex", Constants.logPrefixEditor));
#endif
            _onRnDSpawn = true;
        }

        void Update()
        {
            if (_onRnDSpawn)
            {
                _onRnDSpawn = false;
                if (_techNodeCreated)
                {
#if (DEBUG)
                    Debug.Log(string.Format("{0} Tech node already created", Constants.logPrefixEditor));
#endif
                    return;
                }

                var nodes = GameObject.FindObjectsOfType<RDNode>();

                if (nodes == null || nodes.Length == 0)
                {
                    Debug.LogError("No RDnodes found!");
                }
                else Debug.Log("Found " + nodes.Length + " RD nodes!");
                RDNode[] modelNode = GameObject.FindObjectsOfType(typeof(RDNode)).Cast<RDNode>().Where(a => a.treeNode && string.Equals(a.tech.techID, "basicRocketry")).ToArray();

                if (0 == modelNode.Length)
                {
                    Debug.LogError(string.Format("{0}{1} Couldn't find the basicRocketry tech node.", Constants.logError, Constants.logPrefixEditor));
                    return;
                }

                GameObject newTech = (GameObject)GameObject.Instantiate(modelNode[0].prefab); //new GameObject("node_weld", typeof(RDNode), typeof(RDTech));

                newTech.GetComponent<RDTech>().techID = "welding";
                newTech.GetComponent<RDTech>().hideIfNoParts = false;
                newTech.GetComponent<RDTech>().title = "Welding Tool";
                newTech.GetComponent<RDTech>().description = "Allow you to weld parts";
                newTech.GetComponent<RDTech>().scienceCost = 5;

                newTech.GetComponent<RDNode>().parents = modelNode[0].parents;
                newTech.GetComponent<RDNode>().icon = RDNode.Icon.METAMATERIALS;
                newTech.GetComponent<RDNode>().transform.position = new Vector3(modelNode[0].transform.position.x - 200.0f, modelNode[0].transform.position.y, modelNode[0].transform.position.z);
                newTech.GetComponent<RDNode>().children = new List<RDNode>();
                newTech.GetComponent<RDNode>().prefab = modelNode[0].prefab;
                newTech.GetComponent<RDNode>().controller = modelNode[0].controller;
                newTech.GetComponent<RDNode>().scale = modelNode[0].scale;
                newTech.SetActive(true);

                

                /*if (model == null || model.controller == null)
                {
                    model = (from a in GameObject.FindObjectsOfType(typeof(RDNode)) where ((RDNode)a).treeNode && ((RDNode)a).gameObject.activeSelf select (RDNode)a).First();
                    if (nodePrefab != null && model.controller != null)
                    {
                        Destroy(nodePrefab);
                        nodePrefab = null;
                    }
                }
                if (model.controller != null && model.controller.node_selected != null)
                {
                    model = model.controller.node_selected;
                    if (nodePrefab != null)
                    {
                        Destroy(nodePrefab);
                        nodePrefab = null;
                    }
                }
                if (nodePrefab == null)
                {
                    nodePrefab = new GameObject("weldnode", typeof(RDNode), typeof(RDTech));
                    nodePrefab.GetComponent<RDTech>().techID = "weldnode";
                    nodePrefab.GetComponent<RDNode>().prefab = model.prefab;
                    nodePrefab.GetComponent<RDNode>().parents = new RDNode.Parent[0];
                    nodePrefab.GetComponent<RDNode>().icon = RDNode.Icon.METAMATERIALS;
                    nodePrefab.GetComponent<RDNode>().controller = model.controller;
                    nodePrefab.GetComponent<RDNode>().scale = model.scale;
                    nodePrefab.GetComponent<RDNode>().tech.hideIfNoParts = false;
                    nodePrefab.SetActive(true);
                }
                GameObject clone = (GameObject)GameObject.Instantiate(nodePrefab);
                clone.SetActive(true);
                clone.transform.parent = model.transform.parent;
                clone.transform.localPosition = /*model.transform.localPosition + *//*new Vector3(0, 0, 0);
                clone.GetComponent<RDNode>().children = new List<RDNode>();*/

                nodes = GameObject.FindObjectsOfType<RDNode>();

                if (nodes == null || nodes.Length == 0)
                {
                    Debug.LogError("No RDnodes found!");
                }
                else Debug.Log("Found " + nodes.Length + " RD nodes!");

                _techNodeCreated = true;
            }
        }

        /*void OnGameSceneLoadRequested(GameScenes scene)
        {
            if (_career && scene == GameScenes.SPACECENTER)
            {
                
        }*/

    }
}
