﻿using System;
using System.IO;
using Toolbar;
using UnityEngine;


namespace UbioWeldingLtd
{
    //UbioZurWeldingLtd Class
    [KSPAddon(KSPAddon.Startup.Instantly, false)]
    public class WeldEditor : MonoBehaviour
    {
        private KSP.IO.PluginConfiguration _config;
        private IButton _Buttontoolbar;
        private bool _displayWindow;
        private bool _displayError;
        private bool _displayInfo;
        private bool _displaySettings;
        private Rect _windowPosition;
        private Rect _centerPosition;
        private Rect _infoPosition;
        private Rect _settingPosition;
        private WeldingType _weldType;
        private GUISkin _skinWindow;
        private IWelder _welder;
        private string _cfgDirUrl;
        private string _cfgPartUrl;
        private string _cfgDirPath;
        private string _cfgPartPath;
        private UrlDir _pluginDir;
        private bool _reloadDb;

        internal WeldEditor()
        {
            Debug.Log(string.Format("{0} UbioZur Welding Tool {1} - Editor", Constants.logPrefixEditor, Constants.logVersion));

            //Config
            _config = KSP.IO.PluginConfiguration.CreateForType<WeldEditor>();
            LoadSetConfig();

            //window
            RenderingManager.AddToPostDrawQueue(0, OnDraw);
            _displayError = false;
            _displayWindow = false;
            _displayInfo = false;
            _displaySettings = false;
            _windowPosition = new Rect(_config.GetValue<int>(Constants.settingWindowPosX), _config.GetValue<int>(Constants.settingWindowPosY), Constants.guiEditorWindowWidth, Constants.guiEditorWindowHeight);
            _infoPosition = new Rect(_config.GetValue<int>(Constants.settingWindowInfoPosX), _config.GetValue<int>(Constants.settingWindowInfoPosY), Constants.guiEditorWindowInfoWidth, Constants.guiEditorWindowInfoHeight);
            _centerPosition = new Rect((Screen.width / 2) - (Constants.guiEditorDialWidth / 2), (Screen.height / 2) - (Constants.guiEditorDialHeight / 2), Constants.guiEditorDialWidth, Constants.guiEditorDialHeight);
            _settingPosition = new Rect((Screen.width / 2) - (Constants.guiEditorSettingWidth / 2), (Screen.height / 2) - (Constants.guiEditorSettingHeight / 2), Constants.guiEditorSettingWidth, Constants.guiEditorSettingHeight);

            //Toolbar button
            _Buttontoolbar = ToolbarManager.Instance.add("WeldEditor", "_Buttontoolbar");
            _Buttontoolbar.TexturePath = "UbioWeldingLtd/img_toolbar";
            _Buttontoolbar.ToolTip = Constants.txtButtonToolbarToolTip;
            _Buttontoolbar.OnClick += (e) => toggleWindow(_Buttontoolbar);

            _skinWindow = HighLogic.Skin;

            //Get the plugin dir
            _pluginDir = null;
            foreach (UrlDir dir in GameDatabase.Instance.root.AllDirectories)
            {
                if (null != dir && String.Equals(dir.url, Constants.weldPluginName))
                {
                    _pluginDir = dir;
                    break;
                }
            }
            if (null == _pluginDir)
                Debug.LogError(string.Format("{0}{1}Could not find the plugin url Directory!", Constants.logError, Constants.logPrefixEditor));

            SaveConfig();
        }

        private void LoadSetConfig()
        {
            if (null == _config)
            {
                Debug.LogError(string.Format("{0}{1}Config Variable is NULL!", Constants.logError, Constants.logPrefixEditor));
                return;
            }
            else
            {
                _config.load();
                
                //Set default value if value does not exist or is outside the screen
                int windowPosX = _config.GetValue<int>(Constants.settingWindowPosX, (Screen.width / 2) - (Constants.guiEditorWindowWidth / 2));
                if (0 >= windowPosX || (Screen.width - Constants.guiEditorWindowWidth) <= windowPosX)
                {
                    windowPosX = (Screen.width / 2) - (Constants.guiEditorWindowWidth / 2);
                }
                _config.SetValue(Constants.settingWindowPosX, windowPosX);
                int windowPosY = _config.GetValue<int>(Constants.settingWindowPosY, (Screen.height / 2) - (Constants.guiEditorWindowHeight / 2));
                if (0 >= windowPosY || (Screen.height - Constants.guiEditorWindowHeight) <= windowPosY)
                {
                    windowPosY = (Screen.height / 2) - (Constants.guiEditorWindowHeight / 2);
                }
                _config.SetValue(Constants.settingWindowPosY, windowPosY);
                int windowInfoPosX = _config.GetValue<int>(Constants.settingWindowInfoPosX, (Screen.width / 2) - (Constants.guiEditorWindowInfoWidth / 2));
                if (0 >= windowInfoPosX || (Screen.width - Constants.guiEditorWindowInfoWidth) <= windowInfoPosX)
                {
                    windowInfoPosX = (Screen.width / 2) - (Constants.guiEditorWindowInfoWidth / 2);
                }
                _config.SetValue(Constants.settingWindowInfoPosX, windowPosX);
                int windowInfoPosY = _config.GetValue<int>(Constants.settingWindowInfoPosY, (Screen.height / 2) - (Constants.guiEditorWindowInfoHeight / 2));
                if (0 >= windowInfoPosY || (Screen.height - Constants.guiEditorWindowInfoHeight) <= windowInfoPosY)
                {
                    windowInfoPosY = (Screen.height / 2) - (Constants.guiEditorWindowInfoHeight / 2);
                }
                _config.SetValue(Constants.settingWindowInfoPosY, windowPosY);

                _reloadDb = _config.GetValue<bool>(Constants.settingReloadDb, false);
                _config.SetValue(Constants.settingReloadDb, _reloadDb);

                _weldType = _config.GetValue<WeldingType>(Constants.settingWeldingType, Constants.weldDefaultType);
                _config.SetValue(Constants.settingWeldingType, _weldType);
            }
        }

        private void SaveConfig()
        {
            if (null == _config)
            {
                Debug.LogError(string.Format("{0}{1}Config Variable is NULL!", Constants.logError, Constants.logPrefixEditor));
                return;
            }
            else
            {
                _config.SetValue(Constants.settingWindowPosX, (int)_windowPosition.xMin);
                _config.SetValue(Constants.settingWindowPosY, (int)_windowPosition.yMin);
                _config.SetValue(Constants.settingWindowInfoPosX, (int)_infoPosition.xMin);
                _config.SetValue(Constants.settingWindowInfoPosY, (int)_infoPosition.yMin);
                _config.SetValue(Constants.settingReloadDb, _reloadDb);
                _config.SetValue(Constants.settingWeldingType, _weldType);
                _config.save();
            }
        }

        private void toggleWindow(IButton button)
        {
            if (!_displayInfo && !_displayError)
            {
                if (false == _displayWindow)
                {
                    _displayWindow = true;
                }
                else
                {
                    _displayWindow = false;
                }
                button.Important = false;
            }
        }

        internal void OnDestroy()
        {
            SaveConfig();
            _Buttontoolbar.Destroy();
        }

        private void OnDraw()
        {
            if (null == EditorLogic.fetch)
            {
                return;
            }
            if (_displayWindow)
            {
                _windowPosition = GUI.Window(1, _windowPosition, OnDisplayWindow, Constants.guiEditorWindowTitle);
                if (_displaySettings)
                {
                    //display setting window
                    _settingPosition = GUI.Window(4, _settingPosition, OnDisplaySettings, Constants.guiEditorSettingsTitle);
                }
            }
            else if (_displayError)
            {
                GUILayout.Window(2, _centerPosition, OnErrorDisplay, Constants.guiEditorWindowTitle);
            }
            else if (_displayInfo)
            {
                _infoPosition = GUI.Window(3, _infoPosition, OnDisplayInfo, Constants.guiEditorWindowTitle);
            }
        }

        private void OnErrorDisplay(int windowID)
        {
            GUILayout.BeginVertical();
            GUILayout.BeginHorizontal();
            GUILayout.Label(Constants.txtWeldError);
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.EndHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button(Constants.guiButtonOK))
            {
                _displayWindow = true;
                _displayError = false;
            }
            GUILayout.EndVertical();
        } //private void OnErrorDisplay()

        private void OnDisplayWindow(int windowID)
        {
            //Set the GUI Skin
            GUI.skin = _skinWindow;
            float currentHeight = GUI.skin.window.border.top;
            float typeSize = (Constants.guiEditorWindowWidth * 0.25f) - Constants.guiWindowMargin;
            Rect typeRect = new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, typeSize, Constants.guiWeldTypeRadioHeight);

            //Selection of the Welding Type
            string[] typeName = Enum.GetNames(typeof(WeldingType));
            int selected = (int)_weldType;
            for (int i = 0; i < typeName.Length; ++i)
            {
                bool change = GUI.Toggle(typeRect, selected == i, typeName[i]);
                typeRect.x += typeSize;
                if (change)
                {
                    selected = i;
                    if ((int)_weldType != selected)
                    {
                        _weldType = (WeldingType)selected;
                        Debug.Log(string.Format("{0} Welding type: {1}", Constants.logPrefixEditor, _weldType.ToString()));
                    }
                }
            }
            currentHeight += Constants.guiWeldTypeRadioHeight;

            // Information about the Welding type
            GUI.Label(new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, Constants.guiEditorWindowWidth - 2 * Constants.guiWindowMargin, Constants.guiWeldTypeDescHeight), Constants.txtWeldTypeDesc[(int)_weldType]);
            currentHeight += Constants.guiWeldTypeDescHeight;

            //Display Buttons
            float buttonSize = (Constants.guiEditorWindowWidth * 0.5f) - Constants.guiWindowMargin;
            GUI.enabled = (null != EditorLogic.startPod && null == EditorLogic.SelectedPart);
            if (GUI.Button(new Rect(Constants.guiWindowMargin, currentHeight + Constants.guiWindowMargin, buttonSize, Constants.guiWeldButtonHeight), Constants.txtEditorButtonWeld))
            {
                Debug.Log(string.Format("{0} Trying to Auto Weld with {1}", Constants.logPrefixEditor, _weldType.ToString()));
                OnWeld(EditorLogic.startPod);
            }
            GUI.enabled = true;
            if (GUI.Button(new Rect(Constants.guiWindowMargin + buttonSize, currentHeight + Constants.guiWindowMargin, buttonSize, Constants.guiWeldButtonHeight), Constants.txtEditorButtonSetting))
            {
                _displaySettings = !_displaySettings;
                //Display the settings next to the info window
                if (_displaySettings)
                {
                    float x = _windowPosition.xMax + Constants.guiWindowMargin;
                    float y = _windowPosition.yMin;
                    if (_windowPosition.xMin > Screen.width / 2)
                    {
                        x = _windowPosition.xMin - Constants.guiWindowMargin - Constants.guiEditorSettingWidth;
                    }
                    _settingPosition.Set(x, y, Constants.guiEditorSettingWidth, Constants.guiEditorSettingHeight);
                }
            }
            currentHeight += Constants.guiWeldButtonHeight;
            
            //Drag Welding Button
            GUI.enabled = null != EditorLogic.SelectedPart;
            if (GUI.Button(new Rect(Constants.guiWindowMargin, currentHeight + Constants.guiWindowMargin * 2.0f, Constants.guiEditorWindowWidth - 2 * Constants.guiWindowMargin, Constants.guiWeldDragHeight), Constants.txtEditorDragWeld,_skinWindow.box))
            {
                Debug.Log(string.Format("{0} Trying to Weld Assembly with {1}", Constants.logPrefixEditor, _weldType.ToString()));
                OnWeld(EditorLogic.SelectedPart);
            }
            GUI.enabled = true;
            

            //Allow the drag of the window
            GUI.DragWindow();
        }

        private void OnDisplayInfo(int windowID)
        {
            if (null == _pluginDir)
            {
                Debug.LogError(string.Format("{0}{1}Could not find the plugin url Directory!", Constants.logError, Constants.logPrefixEditor));
                _displayInfo = false;
                _displayWindow = true;
                return;
            }
            //Set the GUI Skin
            GUI.skin = _skinWindow;
            float currentHeight = GUI.skin.window.border.top;

            //Set the name
            float NameSizeLabel = (Constants.guiEditorWindowWidth * 0.25f) - Constants.guiWindowMargin;
            Rect nameLabelRect = new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, NameSizeLabel, Constants.guiInfoTitleHeight);
            GUI.Label(nameLabelRect, Constants.guiInfoNameLabel);
            float NameSizeInput = (Constants.guiEditorWindowWidth * 0.75f) - Constants.guiWindowMargin;
            Rect nameInputRect = new Rect(Constants.guiWindowMargin + NameSizeLabel, Constants.guiWindowMargin + currentHeight, NameSizeInput, Constants.guiInfoTitleHeight);
            _welder.Name = GUI.TextField(nameInputRect, _welder.Name, 100);
            currentHeight += Constants.guiInfoTitleHeight + Constants.guiWindowMargin;

            //Set the title 
            float TitleSizeLabel = (Constants.guiEditorWindowWidth * 0.25f) - Constants.guiWindowMargin;
            Rect titleLabelRect = new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, TitleSizeLabel, Constants.guiInfoTitleHeight);
            GUI.Label(titleLabelRect, Constants.guiInfoTitleLabel);
            float TitleSizeInput = (Constants.guiEditorWindowWidth * 0.75f) - Constants.guiWindowMargin;
            Rect titleInputRect = new Rect(Constants.guiWindowMargin + TitleSizeLabel, Constants.guiWindowMargin + currentHeight, TitleSizeInput, Constants.guiInfoTitleHeight);
            _welder.Title = GUI.TextField(titleInputRect, _welder.Title, 100);
            currentHeight += Constants.guiInfoTitleHeight + Constants.guiWindowMargin;

            //Set the description
            float DescSizeLabel = (Constants.guiEditorWindowWidth * 0.25f) - Constants.guiWindowMargin;
            Rect descLabelRect = new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, DescSizeLabel, Constants.guiInfoDescHeight);
            GUI.Label(descLabelRect, Constants.guiInfoDescLabel);
            float DescSizeInput = (Constants.guiEditorWindowWidth * 0.75f) - Constants.guiWindowMargin;
            Rect descInputRect = new Rect(Constants.guiWindowMargin + DescSizeLabel, Constants.guiWindowMargin + currentHeight, DescSizeInput, Constants.guiInfoDescHeight);
            _welder.Description = GUI.TextField(descInputRect, _welder.Description, 200);
            currentHeight += Constants.guiInfoDescHeight + Constants.guiWindowMargin;
            
            //Set the category (editor visible)
            float catSize = (Constants.guiEditorWindowWidth * 0.25f) - Constants.guiWindowMargin;
            Rect catRect = new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, catSize, Constants.guiInfoCatRadioHeight);

            //Selection of the Category
            string[] catName = Enum.GetNames(typeof(PartCategories));
            int selected = (int)_welder.Category;
            for (int i = 0; i < catName.Length; ++i)
            {
                if (i == 4)
                {
                    catRect.y += Constants.guiWindowMargin + Constants.guiInfoCatRadioHeight;
                    catRect.x = Constants.guiWindowMargin;
                }
                int index = (i == catName.Length - 1) ? -1 : i;
                bool change = GUI.Toggle(catRect, selected == index, catName[i]);
                catRect.x += catSize;
                if (change)
                {
                    selected = index;
                    if ((int)_welder.Category != selected)
                    {
                        _welder.Category = (PartCategories)selected;
                        Debug.Log(string.Format("{0} Category: {1}", Constants.logPrefixEditor, _welder.Category.ToString()));
                    }
                }
            }
            currentHeight += 2 * (Constants.guiWindowMargin + Constants.guiWeldTypeRadioHeight);
            
            //Selection of the Attach Rules
            float AttachSize = (Constants.guiEditorWindowWidth / 3.0f) - Constants.guiWindowMargin;
            Rect AttachRect = new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, AttachSize, Constants.guiInfoAttachRadioHeight);

            GUI.Label(AttachRect, Constants.guiInfoAttachLabel);
            AttachRect.x += AttachSize;
            _welder.AttachRules.stack = GUI.Toggle(AttachRect, _welder.AttachRules.stack, Constants.guiInfoAttachLabelStack);
            AttachRect.x += AttachSize;
            _welder.AttachRules.allowStack = GUI.Toggle(AttachRect, _welder.AttachRules.allowStack, Constants.guiInfoAttachLabelStackAllow);
            AttachRect.x = Constants.guiWindowMargin;
            AttachRect.y += Constants.guiWindowMargin + Constants.guiInfoAttachRadioHeight;
            _welder.AttachRules.srfAttach = GUI.Toggle(AttachRect, _welder.AttachRules.srfAttach, Constants.guiInfoAttachLabelSrf);
            AttachRect.x += AttachSize;
            _welder.AttachRules.allowSrfAttach = GUI.Toggle(AttachRect, _welder.AttachRules.allowSrfAttach, Constants.guiInfoAttachLabelSrfAllow);
            AttachRect.x += AttachSize;
            _welder.AttachRules.allowCollision = GUI.Toggle(AttachRect, _welder.AttachRules.allowCollision, Constants.guiInfoAttachLabelCollision);
            currentHeight += 2 * (Constants.guiWindowMargin + Constants.guiInfoAttachRadioHeight);
            
            //Define if file exist
            generatecfgUrl();
            bool fileexist = GameDatabase.Instance.root.ConfigExists(_cfgPartUrl);

            //Display Buttons
            float buttonSize = (Constants.guiEditorWindowWidth * 0.5f) - Constants.guiWindowMargin;
            GUI.enabled = _welder.isNameNotUsed() || fileexist;
            if (GUI.Button(new Rect(Constants.guiWindowMargin, currentHeight + Constants.guiWindowMargin, buttonSize, Constants.guiInfoButtonHeight), (fileexist) ? Constants.guiInfoButtonOverwrite : Constants.guiInfoButtonValidate))
            {
                Debug.Log(string.Format("{0} Validating weld", Constants.logPrefixEditor));
                //find the urldir
                UrlDir destUrlDir = null; ;
                Debug.Log(string.Format("{0} UrlDir not found in the database, creating it!", Constants.logPrefixEditor));
                UrlDir.ConfigDirectory a = new UrlDir.ConfigDirectory("GameData", String.Format("GameData/{0}", _cfgDirUrl), UrlDir.DirectoryType.GameData);
                destUrlDir = new UrlDir(new UrlDir.ConfigDirectory[] { a }, new UrlDir.ConfigFileType[] { new UrlDir.ConfigFileType(UrlDir.FileType.Config) });

                if (null == destUrlDir)
                {
                    Debug.LogError(string.Format("{0}{1}Could not create the url directory! {2}", Constants.logError, Constants.logPrefixEditor, _cfgDirUrl));
                    _displayInfo = false;
                    _displayWindow = true;
                    return;
                }

                _welder.saveToFile(destUrlDir, _cfgDirPath, Constants.weldPartFile, false);
                //Temp: Reload all Database
                if (_reloadDb)
                {
                    //reload database Big thanks to AncientGammoner (KSP Forum)
                    GameDatabase.Instance.Recompile = true;
                    GameDatabase.Instance.StartLoad();
                    PartLoader.Instance.Recompile = true;
                    PartLoader.Instance.StartLoad();
                }
                _displayInfo = false;
                _displayWindow = true;
            }
            GUI.enabled = true;
            if (GUI.Button(new Rect(Constants.guiWindowMargin + buttonSize, currentHeight + Constants.guiWindowMargin, buttonSize, Constants.guiInfoButtonHeight), Constants.guiInfoButtonCancel))
            {
                Debug.Log(string.Format("{0} Cancel weld", Constants.logPrefixEditor));
                _displayInfo = false;
                _displayWindow = true;
            }
            currentHeight += Constants.guiInfoButtonHeight + Constants.guiWindowMargin;
            
            //Allow the drag of the window
            GUI.DragWindow();
        }

        private void OnDisplaySettings(int windowID)
        {
            //Set the GUI Skin
            GUI.skin = _skinWindow;
            float currentHeight = GUI.skin.window.border.top;
            
            float reloadDbSize = (Constants.guiEditorWindowWidth) - Constants.guiWindowMargin;
            Rect reloadDbRect = new Rect(Constants.guiWindowMargin, Constants.guiWindowMargin + currentHeight, reloadDbSize, Constants.guiSettingReloadDbHeight);
            bool reload = GUI.Toggle(reloadDbRect, _reloadDb, Constants.guiSettingReloadDb);
            if (reload != _reloadDb)
            {
#if (DEBUG)
                Debug.Log(string.Format("{0} Reload Database switched to {1}", Constants.logPrefixEditor, reload));
#endif
                _reloadDb = reload;
                SaveConfig();
            }
            currentHeight += Constants.guiSettingReloadDbHeight + Constants.guiWindowMargin;

            //Display Buttons
            float buttonSize = (Constants.guiEditorSettingWidth * 0.5f) - Constants.guiWindowMargin;
            if (GUI.Button(new Rect(Constants.guiWindowMargin + buttonSize, currentHeight + Constants.guiWindowMargin, buttonSize, Constants.guiSettingButtonHeight), Constants.guiSettingClose))
            {
                SaveConfig();
                _displaySettings = false;
            }
            currentHeight += Constants.guiSettingButtonHeight + Constants.guiWindowMargin;

            //Allow the drag of the window
            GUI.DragWindow();
        }

        private void OnWeld(Part toWeld)
        {
            //Create welder (allow config file to be visible in the editor
            _welder = uwtapi.Instance.create(_weldType, true);
            if (null == _welder)
            {
                Debug.LogError(string.Format("{0}{1}Could not create the welder!", Constants.logError, Constants.logPrefixEditor));
                return;
            }
            //Send the assembly
            _welder.reset();
            if (!_welder.WeldAssembly(toWeld, true))
            {
                //Display error message
                Debug.LogError(string.Format("{0}{1} Could not weld that part with {2}.", Constants.logError, Constants.logPrefixEditor,_weldType.ToString()));
                _displayError = true;
                _displayWindow = false;
            }
            else
            {
                //Display cfg info box
                Debug.Log(string.Format("{0} Parts can be welded with {1}.", Constants.logPrefixEditor, _weldType.ToString()));
                _displayWindow = false;
                _displayInfo = true;
            }
        }

        private void generatecfgUrl()
        {
            if (null != _welder)
            {
                _cfgDirUrl = String.Format("{0}/{1}/{2}/{3}", Constants.weldPluginName, Constants.weldPartPath, _welder.Category.ToString(), _welder.Name);
                _cfgPartUrl = String.Format("{0}/{1}/{2}", _cfgDirUrl, Constants.weldPartFile, _welder.Name);
                _cfgDirPath = UrlDir.PathCombine(KSPUtil.ApplicationRootPath, GameDatabase.Instance.PluginDataFolder);
                _cfgDirPath = UrlDir.PathCombine(_cfgDirPath, "GameData");
                _cfgDirPath = UrlDir.PathCombine(_cfgDirPath, Constants.weldPluginName);
                _cfgDirPath = UrlDir.PathCombine(_cfgDirPath, Constants.weldPartPath);
                _cfgDirPath = UrlDir.PathCombine(_cfgDirPath, _welder.Category.ToString());
                _cfgDirPath = UrlDir.PathCombine(_cfgDirPath, _welder.Name);
                _cfgPartPath = UrlDir.PathCombine(_cfgDirPath, String.Format("{0}.{1}", Constants.weldPartFile, UrlDir.configExtension));
                
#if (DEBUG)
                //Debug.Log(string.Format("{0} Expected config file url: {1}.", Constants.logPrefixEditor, _cfgPartUrl));
#endif
            }
        }
    }
}
