﻿using UnityEngine;

namespace UbioWeldingLtd
{
    static class Constants
    {
        //Log related constants
        public const string logVersion = "v2.0";
        public const string logWarning = "WARNING ";
        public const string logError = "ERROR ";
        public const string logPrefixEditor = "[WeldingToolEditor] ";

        //Text
        public const string txtButtonToolbarToolTip = "UbioZur Welding Tool";
        public const string txtEditorButtonSetting = "Settings";
        public const string txtEditorButtonWeld = "Auto Weld";
        public const string txtEditorDragWeld = "Assembly Drop Zone";
        public static readonly string[] txtWeldTypeDesc = { "Only weld parts of similar type without modules.", 
                                                            "Only weld parts and modules that are known to works together.", 
                                                            "Weld all part to generate a part without any modules/effects.", 
                                                            "Weld all part and module without merging" 
                                                          };
        public const string txtWeldError = "We couldn't weld this assembly with the current setting, check the log file for more information!";

        //GUI
        public const int guiEditorWindowWidth = 400;
        public const int guiEditorWindowHeight = 200;
        public const int guiEditorWindowInfoWidth = 400;
        public const int guiEditorWindowInfoHeight = 290;
        public const int guiEditorDialWidth = 400;
        public const int guiEditorDialHeight = 50;
        public const int guiEditorSettingWidth = 200;
        public const int guiEditorSettingHeight = 75;
        public const string guiEditorWindowTitle = "UbioZur Welding Tool";
        public const string guiButtonOK = " OK ";
        public const float guiWindowMargin = 5.0f;
        public const float guiWeldTypeRadioHeight = 30.0f;
        public const float guiWeldTypeDescHeight = 45.0f;
        public const float guiWeldButtonHeight = 30.0f;
        public const float guiWeldDragHeight = 60.0f;
        public const float guiInfoTitleHeight = 20.0f;
        public const float guiInfoDescHeight = 40.0f;
        public const string guiInfoNameLabel = " Name :";
        public const string guiInfoTitleLabel = " Title :";
        public const string guiInfoDescLabel = " Description :";
        public const float guiInfoCatRadioHeight = 30.0f;
        public const string guiInfoButtonValidate = " Apply ";
        public const string guiInfoButtonOverwrite = "Overwrite";
        public const string guiInfoButtonCancel = " Cancel ";
        public const float guiInfoButtonHeight = 20.0f;
        public const float guiInfoAttachRadioHeight = 30.0f;
        public const string guiInfoAttachLabel = " Attach Rules";
        public const string guiInfoAttachLabelStack = "Stack";
        public const string guiInfoAttachLabelStackAllow = "AllowStack";
        public const string guiInfoAttachLabelSrf = "SrfAttach";
        public const string guiInfoAttachLabelSrfAllow = "AllowSrf";
        public const string guiInfoAttachLabelCollision = "Collision";
        public const string guiSettingReloadDb = "Reload Database";
        public const float guiSettingReloadDbHeight = 20.0f;
        public const float guiSettingButtonHeight = 20.0f;
        public const string guiSettingClose = " Close ";
        public const string guiEditorSettingsTitle = "UWT - Settings";

        //Welding
        public const WeldingType weldDefaultType = WeldingType.VerySafe;
        public const string weldPluginName = "UbioWeldingLtd";
        public const string weldPartPath = "Parts";
        public const string weldPartFile = "part";

        //ConfigFile
        public const string settingWindowPosX = "windowPosX";
        public const string settingWindowPosY = "windowPosY";
        public const string settingWindowInfoPosX = "windowInfoPosX";
        public const string settingWindowInfoPosY = "windowInfoPosY";
        public const string settingReloadDb = "reloadDatabase";
        public const string settingWeldingType = "weldingType";
    }
}
